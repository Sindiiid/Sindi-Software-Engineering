import sqlite3

DB_FILE = "database.db"

def init_db():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tables (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            capacity INTEGER NOT NULL
        )
    """)
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS reservations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            table_id INTEGER NOT NULL,
            customer_name TEXT NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            FOREIGN KEY(table_id) REFERENCES tables(id)
        )
    """)
    
    conn.commit()
    conn.close()

# Table Operations
def add_table(name, capacity):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO tables (name, capacity) VALUES (?, ?)", (name, capacity))
    conn.commit()
    conn.close()

def get_tables():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM tables")
    tables = cursor.fetchall()
    conn.close()
    return tables

# Reservation Operations
def add_reservation(table_id, customer_name, date, time):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    
    # Check for conflicts
    cursor.execute("""
        SELECT * FROM reservations
        WHERE table_id = ? AND date = ? AND time = ?
    """, (table_id, date, time))
    
    if cursor.fetchone():
        conn.close()
        return False  # Conflict exists
    
    cursor.execute("""
        INSERT INTO reservations (table_id, customer_name, date, time)
        VALUES (?, ?, ?, ?)
    """, (table_id, customer_name, date, time))
    
    conn.commit()
    conn.close()
    return True

def get_reservations():
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT r.id, t.name, r.customer_name, r.date, r.time 
        FROM reservations r 
        JOIN tables t ON r.table_id = t.id
    """)
    reservations = cursor.fetchall()
    conn.close()
    return reservations

def get_available_tables(date, time):
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM tables WHERE id NOT IN (
            SELECT table_id FROM reservations WHERE date = ? AND time = ?
        )
    """, (date, time))
    tables = cursor.fetchall()
    conn.close()
    return tables
