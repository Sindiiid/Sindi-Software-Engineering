import tkinter as tk
from tkinter import ttk, messagebox
import calendar
from datetime import datetime, date
import math
import sqlite3
import random

# ─── Colour Palette: Brown-Beige-Blush ─────────────────────────────
BG           = "#F5EDE3"   # warm linen
BG2          = "#EDE0D4"   # deeper linen
ACCENT       = "#B07D62"   # warm caramel brown
ACCENT2      = "#D4A88A"   # soft tan
ACCENT3      = "#8B5E45"   # deep mocha
BLUSH        = "#E8C4B0"   # blush peach
BLUSH2       = "#F2DDD0"   # lightest blush
ROSE         = "#C9896C"   # dusty rose-brown
TEXT         = "#4A2E1A"   # dark espresso
TEXT2        = "#7A5540"   # medium brown
WHITE        = "#FFF8F4"   # warm white
FRAME_BG     = "#EDE0D4"
ENTRY_BG     = "#FFF8F4"
GOLD         = "#C8A97A"   # warm gold accent
FONT_TITLE   = ("Georgia", 22, "bold italic")
FONT_SECT    = ("Georgia", 13, "bold")
FONT         = ("Georgia", 11)
FONT_SMALL   = ("Georgia", 9)
FONT_BOLD    = ("Georgia", 11, "bold")


# ─── Inline SQLite DB ──────────────────────────────────────────────
DB_PATH = "restaurant.db"

def init_db():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS tables
                   (id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT, capacity INTEGER)""")
    cur.execute("""CREATE TABLE IF NOT EXISTS reservations
                   (id INTEGER PRIMARY KEY AUTOINCREMENT,
                    table_id INTEGER, customer TEXT,
                    date TEXT, time TEXT)""")
    con.commit(); con.close()

def add_table(name, cap):
    con = sqlite3.connect(DB_PATH)
    con.execute("INSERT INTO tables (name,capacity) VALUES (?,?)", (name, cap))
    con.commit(); con.close()

def get_tables():
    con = sqlite3.connect(DB_PATH)
    rows = con.execute("SELECT * FROM tables").fetchall()
    con.close(); return rows

def add_reservation(tid, customer, d, t):
    con = sqlite3.connect(DB_PATH)
    clash = con.execute(
        "SELECT id FROM reservations WHERE table_id=? AND date=? AND time=?",
        (tid, d, t)).fetchone()
    if clash:
        con.close(); return False
    con.execute("INSERT INTO reservations (table_id,customer,date,time) VALUES (?,?,?,?)",
                (tid, customer, d, t))
    con.commit(); con.close(); return True

def get_reservations():
    con = sqlite3.connect(DB_PATH)
    rows = con.execute(
        "SELECT r.id, t.name, r.customer, r.date, r.time "
        "FROM reservations r JOIN tables t ON r.table_id=t.id "
        "ORDER BY r.date, r.time").fetchall()
    con.close(); return rows

def get_available_tables(d, t):
    con = sqlite3.connect(DB_PATH)
    rows = con.execute(
        "SELECT * FROM tables WHERE id NOT IN "
        "(SELECT table_id FROM reservations WHERE date=? AND time=?)", (d, t)).fetchall()
    con.close(); return rows

def delete_reservation(rid):
    con = sqlite3.connect(DB_PATH)
    con.execute("DELETE FROM reservations WHERE id=?", (rid,))
    con.commit(); con.close()

def get_reservation_by_id(rid):
    con = sqlite3.connect(DB_PATH)
    row = con.execute(
        "SELECT r.id, r.table_id, t.name, r.customer, r.date, r.time "
        "FROM reservations r JOIN tables t ON r.table_id=t.id "
        "WHERE r.id=?", (rid,)).fetchone()
    con.close(); return row

def update_reservation(rid, tid, customer, d, t):
    con = sqlite3.connect(DB_PATH)
    # Check clash excluding this reservation itself
    clash = con.execute(
        "SELECT id FROM reservations WHERE table_id=? AND date=? AND time=? AND id!=?",
        (tid, d, t, rid)).fetchone()
    if clash:
        con.close(); return False
    con.execute(
        "UPDATE reservations SET table_id=?, customer=?, date=?, time=? WHERE id=?",
        (tid, customer, d, t, rid))
    con.commit(); con.close(); return True

init_db()


# ═══════════════════════════════════════════════════════════════════
#  FANCY PILL BUTTON
# ═══════════════════════════════════════════════════════════════════
class FancyButton(tk.Canvas):
    def __init__(self, master, text, command=None, width=200, height=40,
                 bg_color=ACCENT, hover_color=ACCENT3, fg_color=WHITE, **kw):
        super().__init__(master, width=width, height=height,
                         bg=master.cget("bg") if hasattr(master, 'cget') else BLUSH2,
                         highlightthickness=0, cursor="hand2", **kw)
        self.command     = command
        self.bg_color    = bg_color
        self.hover_color = hover_color
        self.fg_color    = fg_color
        self.text        = text
        self.w           = width
        self.h           = height
        self._draw(bg_color)
        self.bind("<Enter>",    self._on_enter)
        self.bind("<Leave>",    self._on_leave)
        self.bind("<Button-1>", self._on_click)

    def _draw(self, color):
        self.delete("all")
        r = self.h // 2
        self.create_oval(0, 0, self.h, self.h, fill=color, outline="")
        self.create_oval(self.w - self.h, 0, self.w, self.h, fill=color, outline="")
        self.create_rectangle(r, 0, self.w - r, self.h, fill=color, outline="")
        # Shine highlight
        self.create_oval(6, 4, self.h - 4, self.h // 2,
                         fill=self._lighten(color, 35), outline="", stipple="gray50")
        self.create_text(self.w // 2, self.h // 2, text=self.text,
                         fill=self.fg_color, font=FONT_BOLD)

    def _lighten(self, hex_color, amount):
        h = hex_color.lstrip("#")
        r, g, b = [int(h[i:i+2], 16) for i in (0, 2, 4)]
        return f"#{min(255,r+amount):02x}{min(255,g+amount):02x}{min(255,b+amount):02x}"

    def _on_enter(self, e): self._draw(self.hover_color)
    def _on_leave(self, e): self._draw(self.bg_color)
    def _on_click(self, e):
        self._draw(self.bg_color)
        if self.command: self.command()


# ═══════════════════════════════════════════════════════════════════
#  DECORATIVE HEADER CANVAS
# ═══════════════════════════════════════════════════════════════════
def draw_floral_header(canvas, w, h):
    canvas.delete("all")

    # Gradient bands  (dark mocha → caramel)
    for i in range(h):
        t  = i / h
        r  = int(0x8B + (0xB0 - 0x8B) * t)
        g  = int(0x5E + (0x7D - 0x5E) * t)
        b  = int(0x45 + (0x62 - 0x45) * t)
        canvas.create_line(0, i, w, i, fill=f"#{r:02x}{g:02x}{b:02x}")

    # Soft decorative blobs
    for cx, cy, rad, col in [
        (28, 18, 22, BLUSH),
        (w-36, 14, 18, BLUSH2),
        (w-72, 40, 13, GOLD),
        (55, 54, 14, BLUSH),
        (w//2-85, 12, 10, GOLD),
        (w//2+95, 58, 16, BLUSH2),
        (120, 28, 8, BLUSH2),
        (w-140, 50, 9, BLUSH),
    ]:
        for dr in range(rad, 0, -3):
            canvas.create_oval(cx-dr, cy-dr, cx+dr, cy+dr,
                               fill=col, outline="", stipple="gray25")

    # Gold rule lines
    canvas.create_line(28, h-9, w-28, h-9, fill=GOLD, width=1)
    canvas.create_line(28, h-6, w-28, h-6, fill=BLUSH, width=1)

    # Shadow then title
    canvas.create_text(w//2 + 2, h//2 + 1,
                       text="✦  La Belle Table  ✦",
                       fill="#3A1A08", font=("Georgia", 22, "bold italic"))
    canvas.create_text(w//2, h//2,
                       text="✦  La Belle Table  ✦",
                       fill=WHITE, font=("Georgia", 22, "bold italic"))
    canvas.create_text(w//2, h//2 + 25,
                       text="restaurant reservations",
                       fill=BLUSH2, font=("Georgia", 10, "italic"))


# ═══════════════════════════════════════════════════════════════════
#  SECTION FRAME
# ═══════════════════════════════════════════════════════════════════
class SectionFrame(tk.Frame):
    def __init__(self, master, title, icon="", **kw):
        super().__init__(master, bg=BG2, **kw)
        bar = tk.Frame(self, bg=ACCENT2, height=32)
        bar.pack(fill="x")
        bar.pack_propagate(False)
        tk.Label(bar, text=f" {icon}  {title}",
                 bg=ACCENT2, fg=WHITE,
                 font=("Georgia", 12, "bold italic")).pack(side="left", padx=12)
        self.content = tk.Frame(self, bg=BLUSH2, padx=14, pady=10)
        self.content.pack(fill="x")

    def grid_content(self):
        return self.content


# ═══════════════════════════════════════════════════════════════════
#  BEAUTY ENTRY WITH PLACEHOLDER
# ═══════════════════════════════════════════════════════════════════
class BeautyEntry(tk.Entry):
    def __init__(self, master, placeholder="", **kw):
        self._ph = placeholder
        self._has_ph = bool(placeholder)
        super().__init__(master,
                         bg=ENTRY_BG, fg=TEXT, font=FONT,
                         relief="flat",
                         highlightthickness=1,
                         highlightbackground=ACCENT2,
                         highlightcolor=ACCENT,
                         insertbackground=ACCENT, **kw)
        if placeholder:
            self._show_placeholder()
            self.bind("<FocusIn>",  self._clear_ph)
            self.bind("<FocusOut>", self._restore_ph)

    def _show_placeholder(self):
        self.delete(0, tk.END)
        self.insert(0, self._ph)
        self.config(fg=ACCENT2)
        self._has_ph = True

    def _clear_ph(self, e):
        if self._has_ph:
            self.delete(0, tk.END)
            self.config(fg=TEXT)
            self._has_ph = False

    def _restore_ph(self, e):
        if not self.get():
            self._show_placeholder()

    def get_value(self):
        return "" if self._has_ph else self.get()


# ═══════════════════════════════════════════════════════════════════
#  CALENDAR POPUP
# ═══════════════════════════════════════════════════════════════════
class CalendarPopup(tk.Toplevel):
    def __init__(self, parent, callback, initial=None):
        super().__init__(parent)
        self.overrideredirect(True)
        self.config(bg=BG, highlightbackground=ACCENT, highlightthickness=2)
        self.callback = callback
        now = initial or date.today()
        self.year = now.year
        self.month = now.month
        self._build()
        self._position(parent)
        self.grab_set()

    def _position(self, parent):
        self.update_idletasks()
        x = parent.winfo_rootx()
        y = parent.winfo_rooty() + parent.winfo_height() + 6
        self.geometry(f"+{x}+{y}")

    def _build(self):
        for w in self.winfo_children():
            w.destroy()

        # Header
        hdr = tk.Frame(self, bg=ACCENT)
        hdr.pack(fill="x")
        tk.Button(hdr, text="‹", bg=ACCENT, fg=WHITE, relief="flat",
                  font=("Georgia", 16, "bold"), cursor="hand2",
                  activebackground=ACCENT3, activeforeground=WHITE,
                  command=self._prev).pack(side="left", padx=8, pady=6)
        tk.Label(hdr, text=f"{calendar.month_name[self.month]} {self.year}",
                 bg=ACCENT, fg=WHITE,
                 font=("Georgia", 12, "bold italic")).pack(side="left", expand=True)
        tk.Button(hdr, text="›", bg=ACCENT, fg=WHITE, relief="flat",
                  font=("Georgia", 16, "bold"), cursor="hand2",
                  activebackground=ACCENT3, activeforeground=WHITE,
                  command=self._next).pack(side="right", padx=8)

        grid = tk.Frame(self, bg=BG2, padx=8, pady=8)
        grid.pack()

        for i, d in enumerate(["Mo","Tu","We","Th","Fr","Sa","Su"]):
            tk.Label(grid, text=d, bg=BG2, fg=ACCENT3,
                     font=("Georgia", 9, "bold"), width=3).grid(row=0, column=i, padx=2)

        today = date.today()
        cal   = calendar.monthcalendar(self.year, self.month)
        for r, week in enumerate(cal, 1):
            for c, day in enumerate(week):
                if day == 0:
                    tk.Label(grid, text="", bg=BG2, width=3).grid(row=r, column=c)
                else:
                    is_today = (day == today.day and
                                self.month == today.month and
                                self.year  == today.year)
                    bg = ACCENT if is_today else ENTRY_BG
                    fg = WHITE  if is_today else TEXT
                    b  = tk.Button(grid, text=str(day), width=3,
                                   bg=bg, fg=fg, relief="flat",
                                   font=FONT_SMALL, cursor="hand2",
                                   activebackground=ROSE, activeforeground=WHITE,
                                   command=lambda d=day: self._pick(d))
                    b.grid(row=r, column=c, padx=1, pady=1)
                    b.bind("<Enter>", lambda e, b=b, t=is_today:
                           b.config(bg=ROSE, fg=WHITE))
                    b.bind("<Leave>", lambda e, b=b, t=is_today:
                           b.config(bg=ACCENT if t else ENTRY_BG,
                                    fg=WHITE if t else TEXT))

        tk.Frame(self, bg=GOLD, height=1).pack(fill="x", padx=10)
        tk.Label(self, text="click a day to select",
                 bg=BG, fg=ACCENT2,
                 font=("Georgia", 8, "italic")).pack(pady=5)
        self.bind("<FocusOut>", lambda e: self.destroy())

    def _prev(self):
        self.month -= 1
        if self.month == 0: self.month = 12; self.year -= 1
        self._build()

    def _next(self):
        self.month += 1
        if self.month == 13: self.month = 1; self.year += 1
        self._build()

    def _pick(self, day):
        self.callback(date(self.year, self.month, day))
        self.destroy()


# ═══════════════════════════════════════════════════════════════════
#  TIME PICKER POPUP
# ═══════════════════════════════════════════════════════════════════
class TimePopup(tk.Toplevel):
    def __init__(self, parent, callback):
        super().__init__(parent)
        self.overrideredirect(True)
        self.config(bg=BG, highlightbackground=ACCENT, highlightthickness=2)
        self.callback = callback
        self._build()
        self._position(parent)
        self.grab_set()

    def _position(self, parent):
        self.update_idletasks()
        x = parent.winfo_rootx()
        y = parent.winfo_rooty() + parent.winfo_height() + 6
        self.geometry(f"+{x}+{y}")

    def _build(self):
        tk.Frame(self, bg=ACCENT, height=4).pack(fill="x")
        tk.Label(self, text="Select Time",
                 bg=ACCENT, fg=WHITE,
                 font=("Georgia", 12, "bold italic")).pack(fill="x", pady=6)

        body = tk.Frame(self, bg=BG2, padx=20, pady=16)
        body.pack(padx=12, pady=(0, 12))

        self.hour_var = tk.StringVar(value="12")
        self.min_var  = tk.StringVar(value="00")

        tk.Label(body, text="Hour", bg=BG2, fg=TEXT2,
                 font=("Georgia", 9, "italic")).grid(row=0, column=0, padx=12)
        tk.Spinbox(body, from_=0, to=23, width=4,
                   textvariable=self.hour_var, format="%02.0f",
                   bg=ENTRY_BG, fg=TEXT, font=("Georgia", 18, "bold"),
                   relief="flat", justify="center",
                   buttonbackground=BLUSH,
                   highlightthickness=1,
                   highlightbackground=ACCENT2).grid(row=1, column=0, padx=12)

        tk.Label(body, text=":", bg=BG2, fg=ACCENT,
                 font=("Georgia", 24, "bold")).grid(row=1, column=1)

        tk.Label(body, text="Min", bg=BG2, fg=TEXT2,
                 font=("Georgia", 9, "italic")).grid(row=0, column=2, padx=12)
        tk.Spinbox(body, values=[f"{m:02d}" for m in range(0, 60, 15)],
                   width=4, textvariable=self.min_var,
                   bg=ENTRY_BG, fg=TEXT, font=("Georgia", 18, "bold"),
                   relief="flat", justify="center",
                   buttonbackground=BLUSH,
                   highlightthickness=1,
                   highlightbackground=ACCENT2).grid(row=1, column=2, padx=12)

        tk.Frame(self, bg=GOLD, height=1).pack(fill="x", padx=10, pady=(0, 8))
        FancyButton(self, "✓  Confirm", self._confirm,
                    width=160, height=36).pack(pady=(0, 10))

    def _confirm(self):
        h = int(self.hour_var.get())
        m = self.min_var.get()
        self.callback(f"{h:02d}:{m}")
        self.destroy()


# ═══════════════════════════════════════════════════════════════════
#  EDIT RESERVATION MODAL
# ═══════════════════════════════════════════════════════════════════
class EditReservationModal(tk.Toplevel):
    def __init__(self, parent, reservation_id, on_save):
        super().__init__(parent)
        self.title("Edit Reservation")
        self.config(bg=BG, highlightbackground=ACCENT, highlightthickness=2)
        self.resizable(False, False)
        self.on_save = on_save
        self.rid = reservation_id
        self.grab_set()

        # Load current data
        row = get_reservation_by_id(reservation_id)
        # row = (id, table_id, table_name, customer, date, time)
        self._current_tid = row[1]

        # Header
        hdr = tk.Frame(self, bg=ACCENT3)
        hdr.pack(fill="x")
        tk.Label(hdr, text="  ✏️   Edit Reservation",
                 bg=ACCENT3, fg=WHITE,
                 font=("Georgia", 13, "bold italic")).pack(side="left", padx=14, pady=10)
        tk.Button(hdr, text="✕", bg=ACCENT3, fg=WHITE, relief="flat",
                  font=("Georgia", 12, "bold"), cursor="hand2",
                  activebackground=ROSE, activeforeground=WHITE,
                  command=self.destroy).pack(side="right", padx=12)

        # Body
        body = tk.Frame(self, bg=BLUSH2, padx=20, pady=16)
        body.pack(fill="both", padx=12, pady=12)

        def lbl(text, r):
            tk.Label(body, text=text, bg=BLUSH2, fg=TEXT2,
                     font=FONT).grid(row=r, column=0, sticky="w", padx=6, pady=7)

        # Table dropdown
        lbl("Table:", 0)
        tables = get_tables()
        table_opts = [f"{t[0]}: {t[1]}  (seats {t[2]})" for t in tables]
        self.combo = ttk.Combobox(body, values=table_opts, width=24,
                                  state="readonly", font=FONT)
        # Pre-select current table
        for i, opt in enumerate(table_opts):
            if opt.startswith(f"{row[1]}:"):
                self.combo.current(i)
                break
        self.combo.grid(row=0, column=1, columnspan=2, padx=6, pady=7)

        # Customer
        lbl("Customer:", 1)
        self.entry_cust = BeautyEntry(body, width=24)
        self.entry_cust.insert(0, row[3])
        self.entry_cust.grid(row=1, column=1, padx=6, pady=7)

        # Date
        lbl("Date:", 2)
        self.date_var = tk.StringVar(value=row[4])
        date_e = tk.Entry(body, textvariable=self.date_var, width=14,
                          state="readonly", readonlybackground=ENTRY_BG,
                          fg=TEXT, font=FONT, relief="flat",
                          highlightthickness=1, highlightbackground=ACCENT2,
                          cursor="hand2")
        date_e.grid(row=2, column=1, padx=6, pady=7, sticky="w")
        date_ic = tk.Label(body, text="📅", bg=BLUSH2,
                           font=("Helvetica", 13), cursor="hand2")
        date_ic.grid(row=2, column=2, padx=2)
        def open_cal(e=None):
            try: init = datetime.strptime(self.date_var.get(), "%Y-%m-%d").date()
            except: init = None
            CalendarPopup(date_e, lambda d: self.date_var.set(d.strftime("%Y-%m-%d")), init)
        date_e.bind("<Button-1>", open_cal)
        date_ic.bind("<Button-1>", open_cal)

        # Time
        lbl("Time:", 3)
        self.time_var = tk.StringVar(value=row[5])
        time_e = tk.Entry(body, textvariable=self.time_var, width=10,
                          state="readonly", readonlybackground=ENTRY_BG,
                          fg=TEXT, font=FONT, relief="flat",
                          highlightthickness=1, highlightbackground=ACCENT2,
                          cursor="hand2")
        time_e.grid(row=3, column=1, padx=6, pady=7, sticky="w")
        time_ic = tk.Label(body, text="🕐", bg=BLUSH2,
                           font=("Helvetica", 13), cursor="hand2")
        time_ic.grid(row=3, column=2, padx=2)
        def open_time(e=None):
            TimePopup(time_e, self.time_var.set)
        time_e.bind("<Button-1>", open_time)
        time_ic.bind("<Button-1>", open_time)

        # Gold divider
        tk.Frame(self, bg=GOLD, height=1).pack(fill="x", padx=16, pady=(0, 4))

        # Buttons row
        btn_row = tk.Frame(self, bg=BG)
        btn_row.pack(pady=(4, 16))
        FancyButton(btn_row, "💾  Save Changes", self._save,
                    width=180, height=38,
                    bg_color=ACCENT, hover_color=ACCENT3).pack(side="left", padx=8)
        FancyButton(btn_row, "Cancel", self.destroy,
                    width=110, height=38,
                    bg_color=ACCENT2, hover_color=ROSE,
                    fg_color=TEXT).pack(side="left", padx=8)

        # Center on parent
        self.update_idletasks()
        pw = parent.winfo_width();  ph = parent.winfo_height()
        px = parent.winfo_x();      py = parent.winfo_y()
        mw = self.winfo_width();    mh = self.winfo_height()
        self.geometry(f"+{px + (pw-mw)//2}+{py + (ph-mh)//2}")

    def _save(self):
        sel = self.combo.get()
        if not sel:
            show_toast("Please select a table.", success=False); return
        tid      = int(sel.split(":")[0])
        customer = self.entry_cust.get().strip()
        d        = self.date_var.get()
        t        = self.time_var.get()
        if not all([customer, d, t]):
            show_toast("All fields are required.", success=False); return
        if update_reservation(self.rid, tid, customer, d, t):
            show_toast(f"Reservation updated for {customer} ✨", success=True)
            self.on_save()
            self.destroy()
        else:
            show_toast("That table is already booked at this time.", success=False)


# ─── Field builders ────────────────────────────────────────────────
def make_date_field(parent, row, label):
    tk.Label(parent, text=label, bg=BLUSH2, fg=TEXT2,
             font=FONT).grid(row=row, column=0, sticky="w", padx=6, pady=6)
    var = tk.StringVar()
    e = tk.Entry(parent, textvariable=var, width=14, state="readonly",
                 readonlybackground=ENTRY_BG, fg=TEXT, font=FONT,
                 relief="flat", highlightthickness=1,
                 highlightbackground=ACCENT2, cursor="hand2")
    e.grid(row=row, column=1, padx=6, pady=6, sticky="w")
    ic = tk.Label(parent, text="📅", bg=BLUSH2,
                  font=("Helvetica", 13), cursor="hand2")
    ic.grid(row=row, column=2, padx=2)
    def open_cal(ev=None):
        try: init = datetime.strptime(var.get(), "%Y-%m-%d").date()
        except: init = None
        CalendarPopup(e, lambda d: var.set(d.strftime("%Y-%m-%d")), init)
    e.bind("<Button-1>", open_cal)
    ic.bind("<Button-1>", open_cal)
    return var

def make_time_field(parent, row, label):
    tk.Label(parent, text=label, bg=BLUSH2, fg=TEXT2,
             font=FONT).grid(row=row, column=0, sticky="w", padx=6, pady=6)
    var = tk.StringVar()
    e = tk.Entry(parent, textvariable=var, width=10, state="readonly",
                 readonlybackground=ENTRY_BG, fg=TEXT, font=FONT,
                 relief="flat", highlightthickness=1,
                 highlightbackground=ACCENT2, cursor="hand2")
    e.grid(row=row, column=1, padx=6, pady=6, sticky="w")
    ic = tk.Label(parent, text="🕐", bg=BLUSH2,
                  font=("Helvetica", 13), cursor="hand2")
    ic.grid(row=row, column=2, padx=2)
    def open_time(ev=None):
        TimePopup(e, var.set)
    e.bind("<Button-1>", open_time)
    ic.bind("<Button-1>", open_time)
    return var


# ═══════════════════════════════════════════════════════════════════
#  MAIN WINDOW
# ═══════════════════════════════════════════════════════════════════
root = tk.Tk()
root.title("La Belle Table — Reservations")
root.geometry("780x900")
root.config(bg=BG)
root.resizable(True, True)

# ── Decorative header ──
hdr_canvas = tk.Canvas(root, width=780, height=90, highlightthickness=0)
hdr_canvas.pack(fill="x")
root.after(50, lambda: draw_floral_header(hdr_canvas, 780, 90))

# ── Double gold rule ──
tk.Frame(root, bg=GOLD, height=2).pack(fill="x")
tk.Frame(root, bg=BLUSH, height=1).pack(fill="x")

# ── Scrollable body ──
outer  = tk.Frame(root, bg=BG)
outer.pack(fill="both", expand=True)
canvas = tk.Canvas(outer, bg=BG, highlightthickness=0)
vbar   = tk.Scrollbar(outer, orient="vertical", command=canvas.yview)
canvas.configure(yscrollcommand=vbar.set)
vbar.pack(side="right", fill="y")
canvas.pack(side="left", fill="both", expand=True)
body   = tk.Frame(canvas, bg=BG)
cwin   = canvas.create_window((0, 0), window=body, anchor="nw")

def _on_cfg(e):
    canvas.configure(scrollregion=canvas.bbox("all"))
    canvas.itemconfig(cwin, width=canvas.winfo_width())

body.bind("<Configure>", _on_cfg)
canvas.bind("<Configure>", _on_cfg)
root.bind("<MouseWheel>",
          lambda e: canvas.yview_scroll(-1*(e.delta//120), "units"))


# ══════════════════════════════════════════════════════
#  ✨ LIVE CLOCK + DATE
# ══════════════════════════════════════════════════════
clock_bar = tk.Frame(body, bg=BG2)
clock_bar.pack(fill="x", padx=20, pady=(12, 0))

date_lbl = tk.Label(clock_bar, bg=BG2, fg=TEXT2,
                    font=("Georgia", 9, "italic"))
date_lbl.pack(side="left", padx=10, pady=4)

time_lbl = tk.Label(clock_bar, bg=BG2, fg=ACCENT3,
                    font=("Georgia", 13, "bold"))
time_lbl.pack(side="right", padx=10, pady=4)

def tick():
    now = datetime.now()
    time_lbl.config(text=now.strftime("🕰  %H:%M:%S"))
    date_lbl.config(text=now.strftime("%A, %d %B %Y"))
    root.after(1000, tick)

tick()

# Gold micro-rule
tk.Frame(body, bg=GOLD, height=1).pack(fill="x", padx=20, pady=6)


# ══════════════════════════════════════════════════════
#  ✨ ROTATING DAILY QUOTE
# ══════════════════════════════════════════════════════
quotes = [
    "Good food is the foundation of genuine happiness.",
    "A meal shared is a memory made.",
    "Every table tells a story.",
    "Life is too short for bad coffee or empty tables.",
    "Hospitality is making every guest feel at home.",
    "The secret ingredient is always love.",
    "Great restaurants are a gift to civilization.",
]
quote_bar = tk.Frame(body, bg=BLUSH, padx=16, pady=8)
quote_bar.pack(fill="x", padx=20, pady=(0, 8))
quote_lbl = tk.Label(quote_bar,
                     text=f'✦  "{random.choice(quotes)}"',
                     bg=BLUSH, fg=TEXT2,
                     font=("Georgia", 9, "italic"),
                     wraplength=600)
quote_lbl.pack()


# ══════════════════════════════════════════════════════
#  1. ADD TABLE
# ══════════════════════════════════════════════════════
s1 = SectionFrame(body, "Add a Table", icon="🍽")
s1.pack(fill="x", padx=20, pady=(4, 8))
c1 = s1.grid_content()

tk.Label(c1, text="Table Name:", bg=BLUSH2, fg=TEXT2, font=FONT).grid(
    row=0, column=0, sticky="w", padx=6, pady=6)
entry_table_name = BeautyEntry(c1, placeholder="e.g. Garden Table", width=22)
entry_table_name.grid(row=0, column=1, padx=6, pady=6)

tk.Label(c1, text="Capacity:", bg=BLUSH2, fg=TEXT2, font=FONT).grid(
    row=1, column=0, sticky="w", padx=6, pady=6)
entry_table_cap = BeautyEntry(c1, placeholder="e.g. 4", width=10)
entry_table_cap.grid(row=1, column=1, padx=6, pady=6, sticky="w")

def handle_add_table():
    name = entry_table_name.get_value().strip()
    cap  = entry_table_cap.get_value().strip()
    if name and cap.isdigit() and int(cap) > 0:
        add_table(name, int(cap))
        entry_table_name._show_placeholder()
        entry_table_cap._show_placeholder()
        show_toast("Table added successfully ✨", success=True)
        update_table_options()
    else:
        show_toast("Please enter a valid name and a number for capacity.", success=False)

FancyButton(c1, "➕  Add Table", handle_add_table,
            width=180, height=38,
            bg_color=ACCENT, hover_color=ACCENT3).grid(
    row=2, column=0, columnspan=3, pady=12)


# ══════════════════════════════════════════════════════
#  2. MAKE A RESERVATION
# ══════════════════════════════════════════════════════
s2 = SectionFrame(body, "Make a Reservation", icon="📋")
s2.pack(fill="x", padx=20, pady=8)
c2 = s2.grid_content()

tk.Label(c2, text="Table:", bg=BLUSH2, fg=TEXT2, font=FONT).grid(
    row=0, column=0, sticky="w", padx=6, pady=6)

style = ttk.Style()
style.configure("Brown.TCombobox",
                fieldbackground=ENTRY_BG,
                background=BLUSH,
                foreground=TEXT,
                selectbackground=ACCENT2,
                selectforeground=TEXT)
combo_table = ttk.Combobox(c2, width=24, state="readonly",
                            font=FONT, style="Brown.TCombobox")
combo_table.grid(row=0, column=1, padx=6, pady=6, columnspan=2)

tk.Label(c2, text="Customer:", bg=BLUSH2, fg=TEXT2, font=FONT).grid(
    row=1, column=0, sticky="w", padx=6, pady=6)
entry_customer = BeautyEntry(c2, placeholder="Full name", width=24)
entry_customer.grid(row=1, column=1, padx=6, pady=6)

date_var = make_date_field(c2, 2, "Date:")
time_var = make_time_field(c2, 3, "Time:")

def handle_reserve():
    sel = combo_table.get()
    if not sel:
        show_toast("Please select a table.", success=False); return
    tid      = int(sel.split(":")[0])
    customer = entry_customer.get_value().strip()
    d        = date_var.get()
    t        = time_var.get()
    if not all([customer, d, t]):
        show_toast("All fields are required.", success=False); return
    if add_reservation(tid, customer, d, t):
        show_toast(f"Reservation confirmed for {customer} 🎉", success=True)
        entry_customer._show_placeholder()
        date_var.set(""); time_var.set("")
        update_reservations()
    else:
        show_toast("That table is already booked at this time.", success=False)

FancyButton(c2, "💌  Confirm Reservation", handle_reserve,
            width=230, height=38,
            bg_color=ROSE, hover_color=ACCENT3).grid(
    row=4, column=0, columnspan=3, pady=12)


# ══════════════════════════════════════════════════════
#  3. CHECK AVAILABILITY
# ══════════════════════════════════════════════════════
s3 = SectionFrame(body, "Check Availability", icon="🔍")
s3.pack(fill="x", padx=20, pady=8)
c3 = s3.grid_content()

check_date_var = make_date_field(c3, 0, "Date:")
check_time_var = make_time_field(c3, 1, "Time:")

c3.columnconfigure(0, weight=1)
c3.columnconfigure(1, weight=1)
c3.columnconfigure(2, weight=1)

list_wrap3 = tk.Frame(c3, bg=ENTRY_BG,
                       highlightthickness=1, highlightbackground=ACCENT2)
list_wrap3.grid(row=2, column=0, columnspan=4,
                padx=6, pady=6, sticky="nswe")
list_wrap3.columnconfigure(0, weight=1)

hscroll3 = tk.Scrollbar(list_wrap3, orient="horizontal", bg=BLUSH,
                         troughcolor=BLUSH2, activebackground=ACCENT)
hscroll3.pack(side="bottom", fill="x")
listbox_avail = tk.Listbox(list_wrap3, height=4,
                            bg=ENTRY_BG, fg=TEXT, font=FONT,
                            relief="flat", bd=0,
                            selectbackground=BLUSH, selectforeground=TEXT,
                            activestyle="none",
                            xscrollcommand=hscroll3.set)
listbox_avail.pack(fill="both", expand=True, padx=4, pady=4)
hscroll3.config(command=listbox_avail.xview)

def handle_check():
    d = check_date_var.get()
    t = check_time_var.get()
    if not d or not t:
        show_toast("Choose a date and time first.", success=False); return
    tables = get_available_tables(d, t)
    listbox_avail.delete(0, tk.END)
    if tables:
        for tb in tables:
            listbox_avail.insert(tk.END,
                f"   ✦  {tb[1]}  —  seats {tb[2]} guests")
    else:
        listbox_avail.insert(tk.END, "   No tables available for this slot.")

FancyButton(c3, "🔎  Check Now", handle_check,
            width=170, height=36,
            bg_color=ACCENT, hover_color=ACCENT3).grid(
    row=3, column=0, columnspan=3, pady=10)


# ══════════════════════════════════════════════════════
#  4. UPCOMING RESERVATIONS
# ══════════════════════════════════════════════════════
s4 = SectionFrame(body, "Upcoming Reservations", icon="📅")
s4.pack(fill="x", padx=20, pady=(8, 4))
c4 = s4.grid_content()

# Stats counter
stats_row = tk.Frame(c4, bg=BLUSH2)
stats_row.grid(row=0, column=0, columnspan=3, sticky="we", pady=(0, 8))
total_lbl = tk.Label(stats_row, bg=BLUSH, fg=TEXT2,
                     font=("Georgia", 9, "italic"),
                     padx=12, pady=4)
total_lbl.pack(side="left", padx=4)

hint_lbl = tk.Label(stats_row, text="← select a row, then edit or delete",
                    bg=BLUSH, fg=ACCENT2,
                    font=("Georgia", 8, "italic"), padx=8)
hint_lbl.pack(side="right", padx=4)

c4.columnconfigure(0, weight=1)
c4.columnconfigure(1, weight=1)
c4.columnconfigure(2, weight=1)

list_wrap4 = tk.Frame(c4, bg=ENTRY_BG,
                       highlightthickness=1, highlightbackground=ACCENT2)
list_wrap4.grid(row=1, column=0, columnspan=3, sticky="nswe", padx=2)

hscroll4 = tk.Scrollbar(list_wrap4, orient="horizontal",
                         bg=BLUSH, troughcolor=BLUSH2, activebackground=ACCENT)
hscroll4.pack(side="bottom", fill="x")
vscroll4 = tk.Scrollbar(list_wrap4, orient="vertical",
                         bg=BLUSH, troughcolor=BLUSH2, activebackground=ACCENT)
vscroll4.pack(side="right", fill="y")
listbox_res = tk.Listbox(list_wrap4, height=8,
                          bg=ENTRY_BG, fg=TEXT, font=FONT,
                          relief="flat", bd=0,
                          selectbackground=BLUSH, selectforeground=TEXT,
                          activestyle="underline",
                          xscrollcommand=hscroll4.set,
                          yscrollcommand=vscroll4.set,
                          cursor="hand2")
listbox_res.pack(fill="both", expand=True, padx=4, pady=4)
hscroll4.config(command=listbox_res.xview)
vscroll4.config(command=listbox_res.yview)

# Maps listbox index → reservation DB id
_res_id_map = {}

def update_reservations():
    listbox_res.delete(0, tk.END)
    _res_id_map.clear()
    rows = get_reservations()
    total_lbl.config(
        text=f"  {len(rows)} reservation{'s' if len(rows) != 1 else ''}  ")
    if rows:
        for i, r in enumerate(rows):
            # r = (id, table_name, customer, date, time)
            _res_id_map[i] = r[0]
            listbox_res.insert(tk.END,
                f"  ✦  Guest: {r[2]}   |   Table: {r[1]}   |   Date: {r[3]}   |   Time: {r[4]}")
    else:
        listbox_res.insert(tk.END, "   No upcoming reservations yet.")

def _get_selected_id():
    sel = listbox_res.curselection()
    if not sel:
        show_toast("Please select a reservation first.", success=False)
        return None
    idx = sel[0]
    return _res_id_map.get(idx)

def handle_edit():
    rid = _get_selected_id()
    if rid is None: return
    EditReservationModal(root, rid, on_save=update_reservations)

def handle_delete():
    rid = _get_selected_id()
    if rid is None: return
    # Confirm popup
    confirm = tk.Toplevel(root)
    confirm.title("")
    confirm.resizable(False, False)
    confirm.config(bg=BG, highlightbackground=ROSE, highlightthickness=2)
    confirm.grab_set()
    confirm.overrideredirect(True)

    tk.Frame(confirm, bg=ROSE, height=4).pack(fill="x")
    tk.Label(confirm, text="🗑  Delete Reservation?",
             bg=BG, fg=ACCENT3,
             font=("Georgia", 13, "bold italic")).pack(pady=(16, 4), padx=24)
    tk.Label(confirm, text="This action cannot be undone.",
             bg=BG, fg=TEXT2,
             font=("Georgia", 9, "italic")).pack(pady=(0, 14), padx=24)
    tk.Frame(confirm, bg=GOLD, height=1).pack(fill="x", padx=16)

    btn_row = tk.Frame(confirm, bg=BG)
    btn_row.pack(pady=14)

    def do_delete():
        delete_reservation(rid)
        show_toast("Reservation deleted.", success=True)
        update_reservations()
        confirm.destroy()

    FancyButton(btn_row, "🗑  Yes, Delete", do_delete,
                width=150, height=36,
                bg_color="#A0522D", hover_color="#7A3B1E").pack(side="left", padx=8)
    FancyButton(btn_row, "Cancel", confirm.destroy,
                width=110, height=36,
                bg_color=ACCENT2, hover_color=ACCENT,
                fg_color=TEXT).pack(side="left", padx=8)

    # Center
    confirm.update_idletasks()
    pw = root.winfo_width();  ph = root.winfo_height()
    px = root.winfo_x();      py = root.winfo_y()
    mw = confirm.winfo_width(); mh = confirm.winfo_height()
    confirm.geometry(f"+{px+(pw-mw)//2}+{py+(ph-mh)//2}")

def update_table_options():
    tables = get_tables()
    combo_table['values'] = [f"{t[0]}: {t[1]}  (seats {t[2]})" for t in tables]

# Action buttons row
action_row = tk.Frame(c4, bg=BLUSH2)
action_row.grid(row=2, column=0, columnspan=3, pady=10)

FancyButton(action_row, "✏️  Edit Selected", handle_edit,
            width=180, height=36,
            bg_color=ACCENT, hover_color=ACCENT3).pack(side="left", padx=6)

FancyButton(action_row, "🗑  Delete Selected", handle_delete,
            width=190, height=36,
            bg_color="#B07060", hover_color="#7A3B1E").pack(side="left", padx=6)

FancyButton(action_row, "🔄  Refresh", update_reservations,
            width=130, height=36,
            bg_color=ACCENT2, hover_color=ACCENT,
            fg_color=TEXT).pack(side="left", padx=6)


# ══════════════════════════════════════════════════════
#  ✨ FOOTER
# ══════════════════════════════════════════════════════
tk.Frame(body, bg=GOLD, height=2).pack(fill="x", padx=0, pady=(10, 0))
tk.Frame(body, bg=BLUSH, height=1).pack(fill="x")
tk.Label(body, text="La Belle Table  ·  crafted with ♥",
         bg=BG, fg=ACCENT2,
         font=("Georgia", 8, "italic")).pack(pady=8)


# ══════════════════════════════════════════════════════
#  TOAST NOTIFICATION
# ══════════════════════════════════════════════════════
_toast = None

def show_toast(msg, success=True):
    global _toast
    if _toast:
        try: _toast.destroy()
        except: pass
    color = "#6B8F5E" if success else "#9B5130"
    _toast = tk.Label(root, text=f"  {msg}  ",
                      bg=color, fg=WHITE,
                      font=("Georgia", 10, "bold italic"),
                      padx=16, pady=8, relief="flat")
    _toast.place(relx=0.5, rely=0.975, anchor="s")
    root.after(3500, _kill_toast)

def _kill_toast():
    global _toast
    try:
        if _toast: _toast.destroy()
    except: pass
    _toast = None


# ── Initial load ──
update_reservations()
update_table_options()

root.mainloop()